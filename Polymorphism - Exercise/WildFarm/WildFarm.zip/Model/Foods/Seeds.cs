﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Model.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
